# STALKER REIMAGINED (Forge 1.20.1)

Port a Java del addon de Bedrock *Midori's Stalker*. Los 21 stalkers, sus texturas 2D, sonidos, huevos de aparicion
(oval), Enemyte y la barra de comida oculta.

> **Importante:** este proyecto se escribio sin poder compilarlo (el entorno donde se creo no puede descargar Forge).
> Es posible que el primer `build` marque algun error de nombre/firma que haya que corregir. Pasame el log y lo arreglo.

## Compilar el .jar  ->  `STALKER REIMAGINED-1.0.0.jar`

Necesitas **JDK 17**. Elige una forma:

1. **GitHub (sin instalar nada):** sube esta carpeta a un repositorio. La pestana *Actions* ejecuta `.github/workflows/build.yml`
   y deja el .jar como artefacto descargable.
2. **Gradle instalado (8.1.1):** en esta carpeta ejecuta `gradle build`. El .jar queda en `build/libs/`.
3. **Con wrapper:** `gradle wrapper --gradle-version 8.1.1` una vez, y luego `./gradlew build` (Windows: `gradlew.bat build`).

Para probarlo sin empaquetar: `gradle runClient`.

Instalacion: copia el .jar a la carpeta `mods` de Minecraft 1.20.1 con **Forge 47.x** (probado el diseno para 47.3.0).

## Que incluye
- 21 entidades (`/summon stalker_reimagined:luster_stalker`, etc.) con huevos de aparicion en la pestana *STALKER REIMAGINED*.
- Aparicion natural a cualquier hora, **un stalker a la vez** (el Follower y el Distorsionado no cuentan).
- Jumpscare al morir; el Silent (normal o hablando) que te mata hace aparecer al Silent Distorsionado 10 s despues.
- Enemyte + herramientas (nivel diamante), cofre de Enemyte del Orimmy.
- Barra de comida invisible (solo el dibujo; el hambre funciona).

## Que NO se porto (todavia)
- Las Far Lands como estructura generada y "empezar en las Far Lands".
- Las texturas Alpha de bloques (los nombres de Bedrock y Java son distintos).
