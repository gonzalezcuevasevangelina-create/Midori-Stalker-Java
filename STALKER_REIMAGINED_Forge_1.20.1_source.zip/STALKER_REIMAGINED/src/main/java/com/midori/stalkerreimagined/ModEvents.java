package com.midori.stalkerreimagined;

import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = StalkerReimagined.MODID, bus = Mod.EventBusSubscriber.Bus.MOD)
public final class ModEvents {
    private ModEvents() {}

    @SubscribeEvent
    public static void attributes(EntityAttributeCreationEvent event) {
        for (StalkerType t : StalkerType.values()) {
            event.put(StalkerReimagined.TYPES.get(t).get(), StalkerEntity.createAttributes(t).build());
        }
    }
}
