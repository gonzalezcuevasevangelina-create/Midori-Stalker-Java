package com.midori.stalkerreimagined;

import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ClientboundSetTitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitlesAnimationPacket;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.util.Mth;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.ChestBlockEntity;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Un solo tipo de entidad para todos los stalkers: el comportamiento depende de {@link StalkerType#kind}.
 * Es la traduccion de la logica del script del addon de Bedrock (main.js).
 */
public class StalkerEntity extends PathfinderMob {
    private static final EntityDataAccessor<Integer> VARIANT = SynchedEntityData.defineId(StalkerEntity.class, EntityDataSerializers.INT);

    public final StalkerType st;

    // ---- estado general (se guarda en el mundo) ----
    private boolean init;        // ya se coloco / eligio modo
    private boolean chasing;     // persiguiendo
    private int phase;           // fase de la secuencia (depende del tipo)

    // ---- temporizadores (no se guardan) ----
    private int t0, nextA, nextB, nextC, tries;
    private double assistX, assistZ;
    private int assistTick;
    private boolean assistOn;
    private Vec3 base, left, doorPos;
    private BlockPos glass;
    private int poses, poseDelay;
    private int lastAction;

    // Silent
    private int windowCooldown;
    // Bipedal
    private boolean doorDone, hunting;
    private int huntAt;
    // Locust / Follower
    private boolean attackMode;
    // Evil agarre
    private UUID grabbed;
    private int grabLastDamage, grabLowSince, grabCooldown;
    private float grabCeiling;
    private double grabYaw;
    // Tree
    private double treeNear;
    // Boiled
    private double sinkY0;
    // Tormentor
    private int lingerStart;
    // Distorsionado
    private final Map<UUID, Integer> ddNextHit = new HashMap<>();

    public StalkerEntity(EntityType<? extends PathfinderMob> type, Level level, StalkerType st) {
        super(type, level);
        this.st = st;
        this.xpReward = 0;
        this.setPersistenceRequired();
        initGoals(); // st ya esta asignado (registerGoals() se llama desde el constructor padre, antes)
    }

    public static AttributeSupplier.Builder createAttributes(StalkerType t) {
        return PathfinderMob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, t.health)
                .add(Attributes.MOVEMENT_SPEED, t.speed)
                .add(Attributes.ATTACK_DAMAGE, Math.max(0.1, t.damage))
                .add(Attributes.FOLLOW_RANGE, 64.0)
                .add(Attributes.KNOCKBACK_RESISTANCE, 1.0);
    }

    // ------------------------------------------------------------------ datos
    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(VARIANT, 0);
    }

    public int getVariant() { return this.entityData.get(VARIANT); }
    public void setVariant(int v) { this.entityData.set(VARIANT, v); }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putBoolean("Init", init);
        tag.putBoolean("Chasing", chasing);
        tag.putInt("Phase", phase);
        tag.putInt("Variant", getVariant());
        tag.putBoolean("DoorDone", doorDone);
        tag.putBoolean("Hunting", hunting);
        tag.putBoolean("AttackMode", attackMode);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        init = tag.getBoolean("Init");
        chasing = tag.getBoolean("Chasing");
        phase = tag.getInt("Phase");
        setVariant(tag.getInt("Variant"));
        doorDone = tag.getBoolean("DoorDone");
        hunting = tag.getBoolean("Hunting");
        attackMode = tag.getBoolean("AttackMode");
        if (st.kind == StalkerType.Kind.LOCUST && attackMode) getAttribute(Attributes.MOVEMENT_SPEED).setBaseValue(0.36);
    }

    // ------------------------------------------------------------------ comportamiento base
    @Override
    protected void registerGoals() {
        // vacio a proposito: se usa initGoals() porque "st" aun no existe cuando el padre llama a este metodo
    }

    private void initGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        if (st.damage > 0) {
            double mult = switch (st) {
                case EVENT_STALKER, EVILSTALKER, LUSTER_STALKER, ORIMMY_STALKER, THE_LOCUST, HUNTER_STALKER -> 1.3;
                case STALKER, SILENT_STALKER, SILENT_HABLANDO -> 1.2;
                default -> 1.2;
            };
            this.goalSelector.addGoal(2, new MeleeAttackGoal(this, mult, true) {
                @Override public boolean canUse() { return canChase() && super.canUse(); }
                @Override public boolean canContinueToUse() { return canChase() && super.canContinueToUse(); }
            });
            this.targetSelector.addGoal(1, new NearestAttackableTargetGoal<>(this, Player.class, 0, false, false,
                    e -> canChase() && !e.isSpectator()));
        }
    }

    /** true si en este momento le toca perseguir. */
    private boolean canChase() {
        return switch (st.kind) {
            case FREEZE -> st != StalkerType.STALKER_BIPEDAL_DOOR || hunting;
            case HUNTER -> true;
            case FAR_LOOK, YELLING, TORMENT, LOCUST -> chasing;
            default -> false;
        };
    }

    @Override public boolean removeWhenFarAway(double distance) { return false; }
    @Override public boolean isInvulnerableTo(DamageSource source) { return !source.is(DamageTypeTags.BYPASSES_INVULNERABILITY); }
    @Override public boolean isPushable() { return canChase(); }
    @Override public boolean canBeLeashed(Player player) { return false; }

    @Override
    public void remove(RemovalReason reason) {
        if (!level().isClientSide && level() instanceof ServerLevel sl) stopChaseSounds(sl);
        super.remove(reason);
    }

    private ServerLevel sl() { return (ServerLevel) level(); }

    // ------------------------------------------------------------------ tick
    @Override
    public void tick() {
        super.tick();
        if (level().isClientSide) return;
        try {
            serverTick();
        } catch (Exception e) {
            // chunk sin cargar o jugador no valido: se reintenta en el siguiente tick
        }
    }

    private void serverTick() {
        ServerLevel level = sl();
        switch (st.kind) {
            case FREEZE -> tickFreeze(level);
            case HUNTER -> { /* siempre persigue */ }
            case FAR_LOOK -> tickFarLook(level);
            case YELLING -> tickYelling(level);
            case TORMENT -> tickTormentor(level);
            case CAVE -> tickCave(level);
            case DOOR_STALK -> tickDoorStalk(level);
            case HAND -> tickHand(level);
            case PEEKING, TORMENT_DOOR -> tickDoorWindow(level);
            case TREE -> tickTree(level);
            case BOILED -> tickBoiled(level);
            case LOCUST -> tickLocust(level);
            case FOLLOWER -> tickFollower(level);
            case DISTORTED -> tickDistorted(level);
        }
    }

    // ================================================================== utilidades
    private ServerPlayer closest(ServerLevel level, double range) { return Util.nearestPlayer(level, position(), range); }

    private void slowTo(int ticks, int amp) { addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, ticks, amp, false, false)); }

    /** Lo coloca a "far" bloques del jugador si esta mas cerca que minStart. false = chunk sin cargar. */
    private boolean placeFar(ServerLevel level, ServerPlayer p, double far, double minStart) {
        if (Math.hypot(getX() - p.getX(), getZ() - p.getZ()) >= minStart) return true;
        double a = random.nextDouble() * Math.PI * 2;
        return placeAt(level, p, p.getX() + Math.cos(a) * far, p.getZ() + Math.sin(a) * far);
    }

    private boolean placeAt(ServerLevel level, ServerPlayer p, double x, double z) {
        BlockPos s = Util.surface(level, Mth.floor(x), Mth.floor(z));
        if (s == null) return false;
        moveTo(Mth.floor(x) + 0.5, s.getY(), Mth.floor(z) + 0.5, getYRot(), 0);
        getNavigation().stop();
        return true;
    }

    private void tp(Vec3 v) { moveTo(v.x, v.y, v.z, getYRot(), getXRot()); }

    /** Si el juego no lo hace avanzar (creativo, sin camino), lo empuja hacia el jugador. */
    private void assistPush(ServerPlayer target, double step, double stopDist) {
        if (tickCount - assistTick >= 10) {
            if (!assistOn && Math.hypot(getX() - assistX, getZ() - assistZ) < 0.8) assistOn = true;
            assistX = getX(); assistZ = getZ(); assistTick = tickCount;
        }
        if (!assistOn) return;
        double dx = target.getX() - getX(), dz = target.getZ() - getZ();
        double d = Math.hypot(dx, dz);
        if (d <= stopDist) return;
        setPos(getX() + dx / d * step, getY() + (target.getY() > getY() + 1.5 ? 0.2 : 0), getZ() + dz / d * step);
    }

    private void stopChaseSounds(ServerLevel level) {
        for (ServerPlayer p : Util.playersNear(level, position(), 128)) {
            switch (st) {
                case EVENT_STALKER -> { Util.stop(p, ModSounds.EVENT_CHASE_MUSIC.get()); Util.stop(p, ModSounds.EVENT_CHASE_VOICE.get()); }
                case ORIMMY_STALKER -> { Util.stop(p, ModSounds.ORIMMY_CHASE.get()); Util.stop(p, ModSounds.ORIMMY_STALK.get()); }
                case LUSTER_STALKER -> Util.stop(p, ModSounds.LUSTER_CHASE.get());
                case TORMENTOR_DOOR -> Util.stop(p, ModSounds.TORMENTOR_DOOR_LOOK.get());
                case STALKER_BIPEDAL_DOOR -> Util.stop(p, ModSounds.BIPEDAL_DOOR_VOICE.get());
                default -> { }
            }
        }
    }

    private void spawnSmoke(ServerLevel level) {
        for (double h : new double[]{0.4, 1.2, 2.0}) level.sendParticles(ParticleTypes.SMOKE, getX(), getY() + h, getZ(), 6, 0.3, 0.2, 0.3, 0.01);
    }

    // ================================================================== FREEZE: Stalker, Silent, Silent Hablando, Bipedal Door
    private void tickFreeze(ServerLevel level) {
        if (tickCount % 2 != 0) return;
        ServerPlayer p = closest(level, 64);
        boolean silentFamily = st == StalkerType.SILENT_STALKER || st == StalkerType.SILENT_HABLANDO;
        boolean bipedal = st == StalkerType.STALKER_BIPEDAL_DOOR;

        if (bipedal) tickBipedal(level, p);
        if (p == null) return;

        double dist = p.distanceTo(this);
        if (st == StalkerType.SILENT_STALKER && dist <= 32 && tickCount >= nextA) {
            Util.at(level, position(), ModSounds.SILENT_HABLANDO_DOOR.get(), 1.0F, 1.0F);
            nextA = tickCount + 130;
        }

        double aimY = st == StalkerType.SILENT_STALKER ? 2 : 1;
        boolean watched = Util.isLookedAt(p, this, aimY, 0.9, 64);
        if (watched) {
            slowTo(4, 255);
        } else {
            addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 4, 1, false, false));
            if (!silentFamily && !bipedal && dist < 24 && random.nextFloat() < 0.02F) {
                p.playNotifySound(SoundEvents.AMBIENT_CAVE.value(), SoundSource.HOSTILE, 1.0F, 0.7F);
            }
        }
        if (st == StalkerType.SILENT_HABLANDO) slowTo(6, 255); // se queda quieto en la ventana

        if (silentFamily && tickCount % 10 == 0 && !watched) tickSilentActions(level);
    }

    private void tickSilentActions(ServerLevel level) {
        if (st == StalkerType.SILENT_STALKER) {
            if (tickCount >= windowCooldown) {
                BlockPos[] win = Util.windowSpot(level, position(), 5, 3, 1, null, 12);
                if (win != null) swapTo(level, StalkerType.SILENT_HABLANDO, new Vec3(win[1].getX() + 0.5, win[1].getY(), win[1].getZ() + 0.5));
            }
            return;
        }
        // Silent Hablando: rompe vidrio y abre puertas; sin nada que hacer vuelve a Silent
        int broken = breakGlassAround(level);
        if (broken > 0) lastAction = tickCount;
        List<BlockPos> doors = Util.closedDoorsAround(level, blockPosition(), 4);
        if (!doors.isEmpty()) {
            for (BlockPos d : doors) Util.openDoor(level, d);
            lastAction = tickCount;
            Util.at(level, position(), ModSounds.SILENT_HABLANDO_DOOR.get(), 1.0F, 1.0F);
        } else if (broken == 0 && tickCount - lastAction > 60) {
            swapTo(level, StalkerType.SILENT_STALKER, null);
        }
    }

    private int breakGlassAround(ServerLevel level) {
        BlockPos c = blockPosition();
        java.util.ArrayList<BlockPos> glass = new java.util.ArrayList<>();
        for (int dx = -3; dx <= 3; dx++) for (int dy = -1; dy <= 4; dy++) for (int dz = -3; dz <= 3; dz++) {
            BlockPos p = c.offset(dx, dy, dz);
            if (level.hasChunkAt(p) && Util.isGlass(level.getBlockState(p))) glass.add(p);
        }
        glass.sort(java.util.Comparator.comparingDouble(p -> p.distSqr(c)));
        int n = 0;
        for (BlockPos p : glass) {
            if (n++ >= 6) break;
            level.destroyBlock(p, false);
        }
        return Math.min(glass.size(), 6);
    }

    private void swapTo(ServerLevel level, StalkerType target, Vec3 where) {
        StalkerEntity n = StalkerReimagined.TYPES.get(target).get().create(level);
        if (n == null) return;
        Vec3 w = where != null ? where : position();
        n.moveTo(w.x, w.y, w.z, getYRot(), 0);
        n.setHealth(Math.min(getHealth(), n.getMaxHealth()));
        if (hasCustomName()) n.setCustomName(getCustomName());
        n.lastAction = 0;
        if (target == StalkerType.SILENT_STALKER) n.windowCooldown = 40;
        level.addFreshEntity(n);
        discard();
    }

    // ---- Bipedal Door: salta a la puerta mas cercana al jugador, la abre, espera 5 s y ataca ----
    private void tickBipedal(ServerLevel level, ServerPlayer p) {
        if (p != null && !doorDone) {
            doorDone = true;
            BlockPos door = Util.nearestClosedDoor(level, p.position(), 24, 6);
            if (door != null) {
                moveTo(door.getX() + 0.5, door.getY(), door.getZ() + 0.5, getYRot(), 0);
                Util.openDoorsAround(level, door, 2);
                huntAt = tickCount + 100;
            } else {
                huntAt = tickCount;
            }
        }
        if (doorDone && !hunting && tickCount >= huntAt) hunting = true;

        if (doorDone && tickCount % 10 == 0) setVariant(nearAnyDoor(level) ? 0 : 1);

        // aviso con la distancia + voz
        if (tickCount % 10 == 0) {
            for (ServerPlayer pl : Util.playersNear(level, position(), 64)) {
                long dist = Math.round(pl.distanceTo(this));
                pl.displayClientMessage(Component.literal("§cEl stalker está a " + dist + (dist == 1 ? " bloque" : " bloques")), true);
            }
        }
        if (tickCount >= nextB) {
            List<ServerPlayer> near = Util.playersNear(level, position(), 64);
            if (!near.isEmpty()) {
                for (ServerPlayer pl : near) Util.toPlayer(pl, ModSounds.BIPEDAL_DOOR_VOICE.get(), 1.0F);
                nextB = tickCount + 433;
            }
        }
    }

    private boolean nearAnyDoor(ServerLevel level) {
        BlockPos c = blockPosition();
        for (int dx = -1; dx <= 1; dx++) for (int dy = -1; dy <= 2; dy++) for (int dz = -1; dz <= 1; dz++) {
            BlockPos p = c.offset(dx, dy, dz);
            if (!level.hasChunkAt(p) || !Util.isDoor(level.getBlockState(p))) continue;
            double ex = Math.max(Math.max(p.getX() - getX(), 0), getX() - (p.getX() + 1));
            double ey = Math.max(Math.max(p.getY() - getY(), 0), getY() - (p.getY() + 1));
            double ez = Math.max(Math.max(p.getZ() - getZ(), 0), getZ() - (p.getZ() + 1));
            if (Math.sqrt(ex * ex + ey * ey + ez * ez) <= 1.0) return true;
        }
        return false;
    }

    // ================================================================== FAR_LOOK: Event, Evil, Orimmy, Luster
    private double lookCenterY() {
        return switch (st) {
            case EVILSTALKER -> 2.5;
            case LUSTER_STALKER -> 1.5;
            default -> 2.0;
        };
    }

    private void tickFarLook(ServerLevel level) {
        // 1) colocarlo lejos (una vez)
        if (!init) {
            if (tickCount % 20 != 0) return;
            ServerPlayer p = closest(level, 256);
            if (p == null) return;
            if (st == StalkerType.ORIMMY_STALKER && phase == 0) {
                if (!placeOrimmyChest(level, p)) return;
                phase = 1;
            }
            if (st != StalkerType.EVILSTALKER && !placeFar(level, p, 45, 30)) return;
            init = true;
            return;
        }

        ServerPlayer p = closest(level, 128);

        if (chasing) {
            chaseTick(level);
            return;
        }

        // Luster: secuencia watch -> scream -> persecucion
        if (st == StalkerType.LUSTER_STALKER && phase >= 1) {
            lusterSequence(level);
            return;
        }

        // 2) observando: su sonido
        observeSounds(level);

        // 3) si lo miras
        if (tickCount % 5 == 0) {
            for (ServerPlayer pl : Util.playersNear(level, position(), 64)) {
                if (!Util.isLookedAt(pl, this, lookCenterY(), 0.85, 64)) continue;
                startChase(level, pl);
                break;
            }
        }
    }

    private void observeSounds(ServerLevel level) {
        switch (st) {
            case EVENT_STALKER -> {
                if (tickCount < nextA) return;
                nextA = tickCount + 88;
                for (ServerPlayer p : Util.playersNear(level, position(), 48))
                    Util.toPlayer(p, ModSounds.EVENT_VOICE.get(), (float) Math.max(0.3, 1 - p.distanceTo(this) / 48));
            }
            case EVILSTALKER -> {
                if (tickCount < nextA) return;
                nextA = tickCount + 80;
                for (ServerPlayer p : Util.playersNear(level, position(), 64))
                    Util.toPlayer(p, ModSounds.TORMENTOR_WAIT.get(), (float) Math.max(0.3, 1 - p.distanceTo(this) / 64));
            }
            case ORIMMY_STALKER -> {
                if (tickCount < nextA) return;
                nextA = tickCount + 580;
                for (ServerPlayer p : Util.playersNear(level, position(), 48))
                    Util.toPlayer(p, ModSounds.ORIMMY_STALK.get(), (float) Math.max(0.3, 1 - p.distanceTo(this) / 48));
            }
            default -> { }
        }
    }

    private void startChase(ServerLevel level, ServerPlayer looker) {
        switch (st) {
            case EVENT_STALKER -> { chasing = true; setVariant(1); }
            case EVILSTALKER -> {
                chasing = true; setVariant(1);
                looker.connection.send(new ClientboundSetTitlesAnimationPacket(5, 60, 15));
                looker.connection.send(new ClientboundSetTitleTextPacket(Component.literal("§l§c¡Corre antes de que sea tarde!")));
            }
            case ORIMMY_STALKER -> {
                chasing = true; setVariant(1);
                for (ServerPlayer p : Util.playersNear(level, position(), 64)) Util.stop(p, ModSounds.ORIMMY_STALK.get());
            }
            case LUSTER_STALKER -> {
                phase = 2; // sonido watch, quieto
                t0 = tickCount;
                Util.toPlayer(looker, ModSounds.LUSTER_WATCH.get(), 1.0F);
            }
            default -> chasing = true;
        }
    }

    /** Luster: 39 ticks de "watch", cambia de textura con el grito, y 36 ticks despues empieza a perseguir. */
    private void lusterSequence(ServerLevel level) {
        if (phase == 2 && tickCount - t0 >= 39) {
            phase = 3;
            t0 = tickCount;
            setVariant(1);
            for (ServerPlayer p : Util.playersNear(level, position(), 64)) Util.toPlayer(p, ModSounds.LUSTER_SCREAM.get(), 1.0F);
        } else if (phase == 3 && tickCount - t0 >= 36) {
            chasing = true;
            phase = 4;
        }
    }

    private void chaseTick(ServerLevel level) {
        List<ServerPlayer> near = Util.playersNear(level, position(), 64);
        if (!near.isEmpty()) {
            switch (st) {
                case EVENT_STALKER -> {
                    if (tickCount >= nextA) { nextA = tickCount + 196; for (ServerPlayer p : near) Util.toPlayer(p, ModSounds.EVENT_CHASE_VOICE.get(), (float) Math.max(0.5, 1 - p.distanceTo(this) / 64)); }
                    if (tickCount >= nextB) { nextB = tickCount + 700; for (ServerPlayer p : near) Util.toPlayer(p, ModSounds.EVENT_CHASE_MUSIC.get(), 1.0F); }
                }
                case ORIMMY_STALKER -> {
                    if (tickCount >= nextA) { nextA = tickCount + 196; for (ServerPlayer p : near) Util.toPlayer(p, ModSounds.ORIMMY_CHASE.get(), (float) Math.max(0.5, 1 - p.distanceTo(this) / 64)); }
                }
                case LUSTER_STALKER -> {
                    if (tickCount >= nextA) { nextA = tickCount + 345; for (ServerPlayer p : near) Util.toPlayer(p, ModSounds.LUSTER_CHASE.get(), 1.0F); }
                }
                case EVILSTALKER -> {
                    if (tickCount >= nextA && tickCount % 5 == 0) { nextA = tickCount + 137; Util.at(level, position(), ModSounds.TORMENTOR_CHASE.get(), 1.0F, 1.0F); }
                }
                default -> { }
            }
        }
        ServerPlayer target = closest(level, 64);
        if (target == null) return;
        if (st == StalkerType.EVILSTALKER) {
            if (tickCount % 5 == 0) evilBreak(level);
            if (tickCount > 0) evilGrab(level);
            if (grabbed != null) return; // sujetando: no avanza
            assistPush(target, 0.3, 2.5);
        } else {
            assistPush(target, 0.3, 2.0);
        }
    }

    // ---- Orimmy: cofre con enemyte ----
    private boolean placeOrimmyChest(ServerLevel level, ServerPlayer p) {
        for (int i = 0; i < 10; i++) {
            double a = random.nextDouble() * Math.PI * 2;
            double d = 8 + random.nextDouble() * 4;
            int x = Mth.floor(p.getX() + Math.cos(a) * d), z = Mth.floor(p.getZ() + Math.sin(a) * d);
            BlockPos s = Util.surface(level, x, z);
            if (s == null) continue;
            BlockState below = level.getBlockState(s.below());
            if (below.getBlock().getDescriptionId().contains("leaves")) continue;
            if (!level.getBlockState(s).isAir()) continue;
            level.setBlock(s, Blocks.CHEST.defaultBlockState(), 3);
            BlockEntity be = level.getBlockEntity(s);
            if (be instanceof ChestBlockEntity chest) chest.setItem(0, new ItemStack(ModItems.ENEMYTE.get(), 12));
            return true;
        }
        return false;
    }

    // ---- Evil: rompe todo a su paso (menos el suelo) ----
    private void evilBreak(ServerLevel level) {
        BlockPos c = blockPosition();
        int broken = 0;
        for (int dy = 0; dy <= 5; dy++) for (int dx = -2; dx <= 2; dx++) for (int dz = -2; dz <= 2; dz++) {
            BlockPos p = c.offset(dx, dy, dz);
            if (!level.hasChunkAt(p)) continue;
            BlockState s = level.getBlockState(p);
            if (s.isAir() || !s.getFluidState().isEmpty() || s.getDestroySpeed(level, p) < 0) continue;
            boolean container = level.getBlockEntity(p) instanceof net.minecraft.world.Container;
            if (container) level.destroyBlock(p, true); else level.removeBlock(p, false);
            if (++broken >= 60) return;
        }
    }

    // ---- Evil: agarre. Te levanta, te baja la vida poco a poco hasta 1 y termina contigo ----
    private void evilGrab(ServerLevel level) {
        if (grabbed != null) {
            ServerPlayer prey = level.getServer().getPlayerList().getPlayer(grabbed);
            if (prey == null || !prey.isAlive()) { grabbed = null; return; }
            double yaw = Math.toRadians(grabYaw);
            double fx = -Math.sin(yaw), fz = Math.cos(yaw), rx = Math.cos(yaw), rz = Math.sin(yaw);
            setYRot((float) grabYaw);
            prey.connection.teleport(getX() + rx * 1.7 + fx * 0.9, getY() + 1.8, getZ() + rz * 1.7 + fz * 0.9, prey.getYRot(), prey.getXRot());
            prey.setDeltaMovement(Vec3.ZERO);
            prey.fallDistance = 0;
            prey.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 5, 255, false, false));
            if (grabCeiling > 1 && tickCount - grabLastDamage >= 60) {
                grabLastDamage = tickCount;
                grabCeiling = Math.max(1, grabCeiling - 1);
                float diff = prey.getHealth() - grabCeiling;
                if (diff > 0) prey.hurt(damageSources().mobAttack(this), diff);
            }
            if (prey.getHealth() > grabCeiling) prey.setHealth(grabCeiling);
            if (grabCeiling <= 1) {
                if (grabLowSince == 0) grabLowSince = tickCount;
                else if (tickCount - grabLowSince >= 400) {
                    prey.hurt(damageSources().mobAttack(this), 1000.0F);
                    grabbed = null;
                    grabCooldown = tickCount + 200;
                }
            }
            return;
        }
        if (tickCount < grabCooldown) return;
        for (ServerPlayer p : Util.playersNear(level, position(), 4.5)) {
            if (p.isCreative() || p.isSpectator()) continue;
            grabbed = p.getUUID();
            grabYaw = Math.toDegrees(Math.atan2(-(p.getX() - getX()), p.getZ() - getZ()));
            grabCeiling = p.getHealth();
            grabLastDamage = tickCount;
            grabLowSince = 0;
            break;
        }
    }

    // ================================================================== YELLING: cambia de pose (crujido), grita y persigue
    private void tickYelling(ServerLevel level) {
        if (chasing || tickCount % 5 != 0) return;
        if (nextA == 0) { nextA = tickCount + 80 + random.nextInt(120); return; }
        if (tickCount < nextA) return;
        List<ServerPlayer> near = Util.playersNear(level, position(), 48);
        if (near.isEmpty()) return;
        int pose = getVariant();
        if (pose < 5) {
            setVariant(pose + 1);
            for (ServerPlayer p : near) Util.toPlayer(p, ModSounds.YELLING_CRACK.get(), (float) Math.max(0.4, 1 - p.distanceTo(this) / 48));
            nextA = tickCount + 80 + random.nextInt(120);
        } else {
            for (ServerPlayer p : Util.playersNear(level, position(), 64)) Util.toPlayer(p, ModSounds.YELLING.get(), (float) Math.max(0.4, 1 - p.distanceTo(this) / 64));
            chasing = true;
        }
    }

    // ================================================================== TORMENTOR
    private static final String[] LINGER = {
            "ho-hola soy linger tu ayudante te voy a decir algo..",
            "ese mounstro es muy pero muy despiadado y no creo que deberias acercarte porque si no...",
            "No!- *se lo lleva una entidad rara*"};

    private void tickTormentor(ServerLevel level) {
        if (chasing) {
            // mensajes de Linger por partes en la hotbar (azul)
            if (lingerStart >= 0 && tickCount % 10 == 0) {
                int i = (tickCount - lingerStart) / 60;
                if (i >= LINGER.length) { lingerStart = -1; }
                else for (ServerPlayer p : Util.playersNear(level, position(), 128)) p.displayClientMessage(Component.literal("§9" + LINGER[i]), true);
            }
            ServerPlayer target = closest(level, 64);
            if (target != null) assistPush(target, 0.3, 2.0);
            return;
        }
        if (!init) {
            init = true;
            t0 = tickCount;
            for (ServerPlayer p : Util.playersNear(level, position(), 128))
                p.sendSystemMessage(Component.literal("§4<Tormentor> §cte veo desde aquí... Te ves cubierto de mucha carne sabrosa..."));
            return;
        }
        if (tickCount - t0 >= 260) {
            chasing = true;
            lingerStart = tickCount;
        }
    }

    // ================================================================== CAVE STALKER
    private void tickCave(ServerLevel level) {
        ServerPlayer p = closest(level, 256);
        if (p == null) return;
        if (!init) {
            if (tickCount < nextA) return;
            nextA = tickCount + 200;
            Vec3 spot = findCave(level, p);
            if (spot != null) {
                moveTo(spot.x, spot.y, spot.z, getYRot(), 0);
                init = true;
            }
            return;
        }
        if (tickCount % 5 == 0 && p.distanceTo(this) <= 10) {
            spawnSmoke(level);
            discard();
        }
    }

    private static boolean natural(BlockState s) {
        String n = Util.blockName(s);
        for (String k : new String[]{"stone", "dirt", "deepslate", "gravel", "tuff", "andesite", "diorite", "granite", "sand", "clay", "grass_block", "podzol", "mycelium", "netherrack", "basalt"})
            if (n.contains(k)) return true;
        return false;
    }

    private boolean caveSpot(ServerLevel level, int x, int y, int z, int topY) {
        BlockPos p = new BlockPos(x, y, z);
        if (!Util.isFree(level, p) || !Util.isFree(level, p.above()) || !Util.isFree(level, p.above(2))) return false;
        BlockState floor = level.getBlockState(p.below());
        if (floor.isAir() || !floor.getFluidState().isEmpty()) return false;
        int rock = 0;
        for (int yy = y + 3; yy <= Math.min(topY, y + 20) && rock < 3; yy++) {
            if (natural(level.getBlockState(new BlockPos(x, yy, z)))) rock++;
        }
        return rock >= 3;
    }

    private Vec3 findCave(ServerLevel level, ServerPlayer player) {
        int px = Mth.floor(player.getX()), py = Mth.floor(player.getY()), pz = Mth.floor(player.getZ());
        Vec3 eye = player.getEyePosition();
        java.util.ArrayList<int[]> spots = new java.util.ArrayList<>();
        for (int dx = -32; dx <= 32; dx += 2) for (int dz = -32; dz <= 32; dz += 2) {
            int x = px + dx, z = pz + dz;
            BlockPos top = Util.surface(level, x, z);
            if (top == null) continue;
            int topY = top.getY() - 1;
            int yMax = Math.min(py + 12, topY - 4);
            for (int y = py - 24; y <= yMax; y++) {
                int d2 = dx * dx + (y - py) * (y - py) + dz * dz;
                if (d2 < 14 * 14) continue;
                if (caveSpot(level, x, y, z, topY)) spots.add(new int[]{x, y, z, d2});
            }
        }
        if (spots.isEmpty()) return null;
        spots.sort(java.util.Comparator.comparingInt(a -> a[3]));
        int[] pick = spots.get(0);
        for (int i = 0; i < Math.min(40, spots.size()); i++) {
            int[] s = spots.get(i);
            Vec3 from = new Vec3(s[0] + 0.5, s[1] + 1.5, s[2] + 0.5);
            var hit = level.clip(new net.minecraft.world.level.ClipContext(from, eye, net.minecraft.world.level.ClipContext.Block.COLLIDER, net.minecraft.world.level.ClipContext.Fluid.NONE, this));
            if (hit.getType() == net.minecraft.world.phys.HitResult.Type.MISS) { pick = s; break; }
        }
        return new Vec3(pick[0] + 0.5, pick[1], pick[2] + 0.5);
    }

    // ================================================================== DOOR STALK (puerta derecha, 10 s)
    private void tickDoorStalk(ServerLevel level) {
        if (tickCount % 5 != 0) return;
        if (phase == 1) { if (tickCount >= nextB) discard(); return; }
        if (tickCount < nextA) return;
        ServerPlayer p = closest(level, 64);
        if (p == null) return;
        BlockPos door = Util.rightDoor(level, p, 24, 6);
        if (door != null) {
            moveTo(door.getX() + 0.5, door.getY(), door.getZ() + 0.5, getYRot(), 0);
            Util.openDoorsAround(level, door, 2);
            Util.at(level, position(), ModSounds.DOOR_STALK_APPEAR.get(), 1.0F, 1.0F);
            phase = 1;
            nextB = tickCount + 200;
        } else {
            tries++;
            nextA = tickCount + 100;
            if (tries >= 5) { phase = 1; nextB = tickCount + 200; }
        }
    }

    // ================================================================== HAND (puerta derecha, detras, se desliza a la derecha)
    private void tickHand(ServerLevel level) {
        ServerPlayer p = closest(level, 64);
        if (p == null) return;
        if (doorPos == null) {
            if (tickCount < nextA) return;
            BlockPos door = Util.rightDoor(level, p, 24, 6);
            if (door != null) {
                doorPos = new Vec3(door.getX() + 0.5, door.getY(), door.getZ() + 0.5);
                t0 = tickCount;
                Util.openDoorsAround(level, door, 2);
            } else {
                tries++;
                nextA = tickCount + 100;
                if (tries >= 5) discard();
                return;
            }
        }
        double t = (tickCount - t0) / 100.0;
        if (t >= 1 + 20.0 / 100.0) { discard(); return; }
        double vx = doorPos.x - p.getX(), vz = doorPos.z - p.getZ();
        double len = Math.hypot(vx, vz);
        if (len == 0) len = 1;
        vx /= len; vz /= len;
        double rx = -vz, rz = vx;
        double slide = 3.0 * Math.min(1, Math.max(0, t));
        moveTo(doorPos.x + vx * 1.0 + rx * slide, doorPos.y, doorPos.z + vz * 1.0 + rz * slide, getYRot(), 0);
    }

    // ================================================================== PEEKING y TORMENTOR DOOR
    // estados: 0 buscar puerta, 1 asomado (se desliza a la izquierda), 2 buscar ventana, 3-5 poses, 6 romper, fin
    private void tickDoorWindow(ServerLevel level) {
        boolean td = st == StalkerType.TORMENTOR_DOOR;
        int doorTicks = td ? 200 : 160;
        double slideDist = td ? 2.0 : 2.0;
        int step = td ? 2 : 5;

        ServerPlayer p = closest(level, 64);
        if (p == null) return;

        if (phase == 1 && base != null && left != null) { // deslizamiento suave cada tick
            double t = Math.min(1, Math.max(0, (tickCount - t0) / (double) doorTicks));
            moveTo(base.x + left.x * slideDist * t, base.y, base.z + left.z * slideDist * t, getYRot(), 0);
        }
        if (tickCount % step != 0) return;

        if (phase == 0) {
            BlockPos door = Util.nearestClosedDoor(level, p.position(), 24, 6);
            if (door != null) {
                Vec3 dp = new Vec3(door.getX() + 0.5, door.getY(), door.getZ() + 0.5);
                double vx = dp.x - p.getX(), vz = dp.z - p.getZ();
                double len = Math.hypot(vx, vz);
                if (len == 0) len = 1;
                vx /= len; vz /= len;
                base = new Vec3(dp.x + vx, dp.y, dp.z + vz);
                left = new Vec3(vz, 0, -vx);
                moveTo(base.x, base.y, base.z, getYRot(), 0);
                Util.openDoorsAround(level, door, 2);
                t0 = tickCount;
                nextA = tickCount + doorTicks;
                if (td) Util.at(level, base, ModSounds.TORMENTOR_DOOR_LOOK.get(), 1.0F, 1.0F);
                phase = 1;
            } else phase = 2;
        } else if (phase == 1) {
            if (tickCount >= nextA) {
                if (td) {
                    for (ServerPlayer pl : Util.playersNear(level, position(), 64)) Util.stop(pl, ModSounds.TORMENTOR_DOOR_LOOK.get());
                    Util.at(level, position(), ModSounds.TORMENTOR_DOOR_RUN.get(), 1.0F, 1.0F);
                }
                nextA = tickCount;
                phase = 2;
            }
        } else if (phase == 2) {
            if (tickCount < nextA) return;
            BlockPos[] win = Util.windowSpot(level, p.position(), 20, 5, 5, p.position(), 25);
            if (win != null) {
                moveTo(win[1].getX() + 0.5, win[1].getY(), win[1].getZ() + 0.5, getYRot(), 0);
                glass = win[0];
                poses = 0;
                poseDelay = td ? 60 : 60;
                nextA = tickCount + (td ? 40 : 40);
                phase = 3;
            } else {
                tries++;
                nextA = tickCount + 100;
                if (tries >= 3) { nextA = tickCount; poses = 0; poseDelay = 60; phase = 3; }
            }
        } else if (phase >= 3 && phase <= 5) {
            if (tickCount < nextA) return;
            int next = phase == 4 ? 2 : 1;
            setVariant(next);
            if (td) {
                if (next == 2) {
                    Util.at(level, position(), ModSounds.TORMENTOR_DOOR_SCREAM.get(), 1.0F, 1.0F);
                    poseDelay = Math.max(4, Math.round(poseDelay * 0.75F));
                }
            } else {
                Util.at(level, position(), ModSounds.PEEKING_KNOCK.get(), 1.0F, 1.0F);
            }
            poses++;
            int limit = td ? 10 : 5;
            nextA = tickCount + (td ? poseDelay : 60);
            phase = poses >= limit ? 6 : (phase == 4 ? 5 : 4);
        } else if (phase == 6) {
            if (tickCount < nextA) return;
            if (glass != null) Util.breakWindow(level, glass, 16);
            if (td) Util.at(level, position(), ModSounds.TORMENTOR_DOOR_SMASH.get(), 1.0F, 1.0F);
            discard();
        }
    }

    // ================================================================== TREE STALKER
    private void tickTree(ServerLevel level) {
        if (tickCount % 5 != 0) return;
        if (phase == 3) { if (tickCount >= nextB) discard(); return; }
        ServerPlayer p = closest(level, 128);
        if (p == null) return;
        if (phase == 0) {
            if (tickCount < nextA) return;
            Vec3 spot = findTreeSpot(level, p, 12);
            if (spot == null) spot = findTreeSpot(level, p, 3);
            if (spot != null) {
                moveTo(spot.x, spot.y, spot.z, getYRot(), 0);
                phase = 1;
                t0 = tickCount;
                treeNear = Math.max(2, Math.min(9, Math.hypot(p.getX() - spot.x, p.getZ() - spot.z) - 3));
                Util.at(level, spot, ModSounds.TORMENTOR_DOOR_LOOK.get(), 1.0F, 1.0F);
            } else {
                tries++;
                nextA = tickCount + 100;
                if (tries >= 10) discard();
            }
            return;
        }
        double d = Math.hypot(p.getX() - getX(), p.getZ() - getZ());
        if (d <= treeNear) {
            Util.at(level, position(), ModSounds.TORMENTOR_DOOR_RUN.get(), 1.0F, 1.0F);
            phase = 3;
            nextB = tickCount + 40;
        } else if (tickCount - t0 > 2400) {
            discard();
        }
    }

    private boolean passable(ServerLevel level, BlockPos p) {
        BlockState s = level.getBlockState(p);
        return s.isAir() || (s.getFluidState().isEmpty() && !s.isSolid()) ;
    }

    private Integer groundY(ServerLevel level, int x, int baseY, int z) {
        for (int y = baseY + 2; y >= baseY - 3; y--) {
            BlockPos fl = new BlockPos(x, y - 1, z);
            if (passable(level, fl) || !level.getFluidState(fl).isEmpty()) continue;
            if (passable(level, new BlockPos(x, y, z)) && passable(level, new BlockPos(x, y + 1, z)) && passable(level, new BlockPos(x, y + 2, z))) return y;
            return null;
        }
        return null;
    }

    /** Sitio a la IZQUIERDA de un tronco cercano (cualquier madera/hongo). */
    private Vec3 findTreeSpot(ServerLevel level, ServerPlayer player, int minDist) {
        int cx = Mth.floor(player.getX()), cy = Mth.floor(player.getY()), cz = Mth.floor(player.getZ());
        Vec3 view = player.getLookAngle();
        double vl = Math.hypot(view.x, view.z);
        if (vl == 0) vl = 1;
        double vx = view.x / vl, vz = view.z / vl;
        double lx = vz, lz = -vx;
        final int R = 28;
        Vec3 best = null;
        double bestD = Double.MAX_VALUE;
        for (int dx = -R; dx <= R; dx++) for (int dz = -R; dz <= R; dz++) {
            double h = dx * dx + dz * dz;
            if (h < minDist * minDist || h > R * R) continue;
            double front = (dx * vx + dz * vz) / Math.sqrt(h);
            double score = h - front * 150;
            if (score >= bestD) continue;
            for (int dy = -6; dy <= 8; dy++) {
                BlockPos lp = new BlockPos(cx + dx, cy + dy, cz + dz);
                if (!level.hasChunkAt(lp) || !Util.isLog(level.getBlockState(lp))) continue;
                int by = lp.getY();
                for (int i = 0; i < 8; i++) {
                    if (Util.isLog(level.getBlockState(new BlockPos(lp.getX(), by - 1, lp.getZ())))) by--; else break;
                }
                Vec3 found = null;
                outer:
                for (double side : new double[]{1.0, 1.4, 1.8}) for (double back : new double[]{0.45, 0.0}) {
                    double px = lp.getX() + 0.5 + lx * side + vx * back, pz = lp.getZ() + 0.5 + lz * side + vz * back;
                    Integer y = groundY(level, Mth.floor(px), by, Mth.floor(pz));
                    if (y != null) { found = new Vec3(px, y, pz); break outer; }
                }
                if (found == null) {
                    double[][] others = {{-lx, -lz}, {vx, vz}, {-vx, -vz}};
                    for (double[] o : others) {
                        double px = lp.getX() + 0.5 + o[0], pz = lp.getZ() + 0.5 + o[1];
                        Integer y = groundY(level, Mth.floor(px), by, Mth.floor(pz));
                        if (y != null) { found = new Vec3(px, y, pz); break; }
                    }
                }
                if (found == null) found = new Vec3(lp.getX() + 0.5 + lx, by, lp.getZ() + 0.5 + lz); // ultimo recurso: pegado al tronco
                best = found;
                bestD = score;
                break;
            }
        }
        return best;
    }

    // ================================================================== BOILED ONE: te espia; si lo miras se hunde
    private void tickBoiled(ServerLevel level) {
        if (!init) {
            if (tickCount % 20 != 0) return;
            ServerPlayer p = closest(level, 256);
            if (p == null) return;
            if (!placeFar(level, p, 40, 28)) return;
            init = true;
            return;
        }
        if (phase == 0) {
            if (tickCount % 5 != 0) return;
            for (ServerPlayer p : Util.playersNear(level, position(), 64)) {
                if (!Util.isLookedAt(p, this, 2.0, 0.85, 64)) continue;
                phase = 1;
                t0 = tickCount;
                sinkY0 = getY();
                setNoGravity(true);
                break;
            }
            return;
        }
        double t = Math.min(1, (tickCount - t0) / 50.0);
        setPos(getX(), sinkY0 - 4.6 * t, getZ());
        setDeltaMovement(Vec3.ZERO);
        if ((tickCount - t0) % 8 == 0) Util.at(level, position(), SoundEvents.GRAVEL_BREAK, 1.0F, 0.6F);
        if (t >= 1) discard();
    }

    // ================================================================== LOCUST: mirar (y desaparecer) o atacar (con Follower)
    private void tickLocust(ServerLevel level) {
        if (!init) {
            if (tickCount % 20 != 0) return;
            ServerPlayer p = closest(level, 256);
            if (p == null) return;
            boolean attack = random.nextFloat() < 0.5F;
            double lo = attack ? 35 : 25, hi = attack ? 45 : 35;
            double a = random.nextDouble() * Math.PI * 2, d = lo + random.nextDouble() * (hi - lo);
            if (!placeAt(level, p, p.getX() + Math.cos(a) * d, p.getZ() + Math.sin(a) * d)) return;
            init = true;
            if (attack) makeAttackMode(level);
            else { attackMode = false; nextA = tickCount + 600; }
            return;
        }
        if (attackMode && !chasing) { chasing = true; }
        if (!attackMode) {
            if (tickCount % 10 == 0) {
                boolean close = !Util.playersNear(level, position(), 10).isEmpty();
                if (close || tickCount >= nextA) discard();
            }
            return;
        }
        ServerPlayer target = closest(level, 64);
        if (target != null) assistPush(target, 0.3, 2.0);
    }

    /** Pasa a modo ataque (tambien lo usa el spawner de las Far Lands): persigue y trae a su Follower. */
    public void makeAttackMode(ServerLevel level) {
        attackMode = true;
        chasing = true;
        init = true;
        getAttribute(Attributes.MOVEMENT_SPEED).setBaseValue(0.36);
        setPersistenceRequired();
        StalkerEntity f = StalkerReimagined.TYPES.get(StalkerType.THE_FOLLOWER).get().create(level);
        if (f != null) {
            f.moveTo(getX() + 1.5, getY(), getZ() + 1.5, 0, 0);
            level.addFreshEntity(f);
        }
    }

    public boolean isAttackLocust() { return st == StalkerType.THE_LOCUST && attackMode; }

    // ================================================================== FOLLOWER
    private StalkerEntity nearestAttackLocust(ServerLevel level, Vec3 from, double range) {
        StalkerEntity best = null;
        double bd = Double.MAX_VALUE;
        for (StalkerEntity e : level.getEntitiesOfClass(StalkerEntity.class, new AABB(from, from).inflate(range), e -> e.isAttackLocust())) {
            double d = e.position().distanceToSqr(from);
            if (d < bd) { bd = d; best = e; }
        }
        return best;
    }

    private void tickFollower(ServerLevel level) {
        StalkerEntity lo = nearestAttackLocust(level, position(), 256);
        if (lo == null) {
            if (nextA == 0) nextA = tickCount;
            if (tickCount - nextA >= 600) discard();
            return;
        }
        nextA = 0;
        double dx = lo.getX() - getX(), dz = lo.getZ() - getZ(), d = Math.hypot(dx, dz);
        if (d > 48) {
            moveTo(lo.getX() + 2, lo.getY(), lo.getZ() + 2, getYRot(), 0);
        } else if (d > 3) {
            double step = Math.min(0.4, d - 3);
            moveTo(getX() + dx / d * step, lo.getY(), getZ() + dz / d * step, getYRot(), 0);
        }
        // si estas lejos del Locust: lentitud + aviso rojo
        if (tickCount % 10 == 0) {
            for (ServerPlayer p : level.players()) {
                StalkerEntity near = nearestAttackLocust(level, p.position(), 256);
                if (near == null) continue;
                if (Math.hypot(p.getX() - near.getX(), p.getZ() - near.getZ()) <= 20) continue;
                p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 40, 2, false, false));
                p.displayClientMessage(Component.literal("§cSi te mueves va a ser peor..."), true);
            }
        }
    }

    // ================================================================== SILENT DISTORSIONADO: te mira; si te acercas te quita medio corazon rapido
    private void tickDistorted(ServerLevel level) {
        if (tickCount > 600) { discard(); return; }
        if (tickCount >= nextA) {
            nextA = tickCount + 70;
            Util.at(level, position().add(0, 2, 0), ModSounds.SILENT_DISTORSIONADO_STALKING.get(), 1.0F, 1.0F);
        }
        if (tickCount % 2 != 0) return;
        for (ServerPlayer p : Util.playersNear(level, position(), 6)) {
            if (tickCount < ddNextHit.getOrDefault(p.getUUID(), 0)) continue;
            ddNextHit.put(p.getUUID(), tickCount + 10);
            p.hurt(damageSources().mobAttack(this), 1.0F);
        }
    }
}
