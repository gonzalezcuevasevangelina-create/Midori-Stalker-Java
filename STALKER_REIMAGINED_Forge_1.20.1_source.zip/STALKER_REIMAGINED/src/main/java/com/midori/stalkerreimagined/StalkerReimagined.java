package com.midori.stalkerreimagined;

import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

import java.util.EnumMap;
import java.util.Map;

@Mod(StalkerReimagined.MODID)
public class StalkerReimagined {
    public static final String MODID = "stalker_reimagined";

    public static final DeferredRegister<EntityType<?>> ENTITIES = DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, MODID);
    public static final DeferredRegister<CreativeModeTab> TABS = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, MODID);

    public static final Map<StalkerType, RegistryObject<EntityType<StalkerEntity>>> TYPES = new EnumMap<>(StalkerType.class);

    static {
        for (StalkerType t : StalkerType.values()) {
            TYPES.put(t, ENTITIES.register(t.id, () -> EntityType.Builder
                    .<StalkerEntity>of((type, level) -> new StalkerEntity(type, level, t), MobCategory.MONSTER)
                    .sized(t.width, t.height)
                    .clientTrackingRange(10)
                    .build(MODID + ":" + t.id)));
        }
    }

    public static final RegistryObject<CreativeModeTab> TAB = TABS.register("stalker_reimagined", () -> CreativeModeTab.builder()
            .title(Component.translatable("itemGroup." + MODID))
            .icon(() -> new ItemStack(ModItems.EGGS.get(0).get()))
            .displayItems((params, output) -> {
                ModItems.EGGS.forEach(e -> output.accept(e.get()));
                output.accept(ModItems.ENEMYTE.get());
                output.accept(ModItems.ENEMYTE_SWORD.get());
                output.accept(ModItems.ENEMYTE_PICKAXE.get());
                output.accept(ModItems.ENEMYTE_AXE.get());
                output.accept(ModItems.ENEMYTE_SHOVEL.get());
                output.accept(ModItems.ENEMYTE_HOE.get());
            })
            .build());

    public StalkerReimagined() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        ENTITIES.register(bus);
        ModItems.ITEMS.register(bus);
        ModSounds.SOUNDS.register(bus);
        TABS.register(bus);
    }
}
