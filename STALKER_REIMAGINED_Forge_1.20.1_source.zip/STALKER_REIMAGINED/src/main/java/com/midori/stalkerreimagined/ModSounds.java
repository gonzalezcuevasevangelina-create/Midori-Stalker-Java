package com.midori.stalkerreimagined;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModSounds {
    public static final DeferredRegister<SoundEvent> SOUNDS = DeferredRegister.create(ForgeRegistries.SOUND_EVENTS, StalkerReimagined.MODID);

    private static RegistryObject<SoundEvent> reg(String name) {
        return SOUNDS.register(name, () -> SoundEvent.createVariableRangeEvent(new ResourceLocation(StalkerReimagined.MODID, name)));
    }

    public static final RegistryObject<SoundEvent> SILENT_HABLANDO_DOOR = reg("silent_hablando_door");
    public static final RegistryObject<SoundEvent> BIPEDAL_DOOR_VOICE = reg("bipedal_door_voice");
    public static final RegistryObject<SoundEvent> JUMPSCARE = reg("jumpscare");
    public static final RegistryObject<SoundEvent> TORMENTOR_CHASE = reg("tormentor_chase");
    public static final RegistryObject<SoundEvent> TORMENTOR_WAIT = reg("tormentor_wait");
    public static final RegistryObject<SoundEvent> YELLING = reg("yelling");
    public static final RegistryObject<SoundEvent> YELLING_CRACK = reg("yelling_crack");
    public static final RegistryObject<SoundEvent> EVENT_VOICE = reg("event_voice");
    public static final RegistryObject<SoundEvent> PEEKING_KNOCK = reg("peeking_knock");
    public static final RegistryObject<SoundEvent> EVENT_CHASE_VOICE = reg("event_chase_voice");
    public static final RegistryObject<SoundEvent> EVENT_CHASE_MUSIC = reg("event_chase_music");
    public static final RegistryObject<SoundEvent> DOOR_STALK_APPEAR = reg("door_stalk_appear");
    public static final RegistryObject<SoundEvent> ORIMMY_CHASE = reg("orimmy_chase");
    public static final RegistryObject<SoundEvent> ORIMMY_STALK = reg("orimmy_stalk");
    public static final RegistryObject<SoundEvent> TORMENTOR_DOOR_LOOK = reg("tormentor_door_look");
    public static final RegistryObject<SoundEvent> TORMENTOR_DOOR_RUN = reg("tormentor_door_run");
    public static final RegistryObject<SoundEvent> TORMENTOR_DOOR_SCREAM = reg("tormentor_door_scream");
    public static final RegistryObject<SoundEvent> TORMENTOR_DOOR_SMASH = reg("tormentor_door_smash");
    public static final RegistryObject<SoundEvent> SILENT_DISTORSIONADO_STALKING = reg("silent_distorsionado_stalking");
    public static final RegistryObject<SoundEvent> LUSTER_WATCH = reg("luster_watch");
    public static final RegistryObject<SoundEvent> LUSTER_SCREAM = reg("luster_scream");
    public static final RegistryObject<SoundEvent> LUSTER_CHASE = reg("luster_chase");

    private ModSounds() {}
}
